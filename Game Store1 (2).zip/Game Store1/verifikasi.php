<?php
$servername = "localhost";
$username = "root"; // Ganti jika username MySQL Anda berbeda
$password = ""; // Ganti jika password MySQL Anda berbeda
$dbname = "untuk_user"; // Pastikan ini adalah nama database yang benar

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Cek apakah ada data yang dikirim melalui POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomor_transaksi = $_POST['nomor_transaksi']; // Ambil nomor transaksi dari form
    $status = $_POST['status']; // Ambil status baru dari form (success/canceled)

    // Perbarui status di tabel transaksi_user (jika ada)
    $updateTransaksiQuery = "UPDATE transaksi_user SET status = ? WHERE nomor_transaksi = ?";
    $stmt = $conn->prepare($updateTransaksiQuery);
    $stmt->bind_param("ss", $status, $nomor_transaksi);
    $stmt->execute();

    // Perbarui status di tabel riwayat_transaksi
    $updateRiwayatQuery = "UPDATE riwayat_transaksi SET status_pembayaran = ? WHERE nomor_transaksi = ?";
    $stmt = $conn->prepare($updateRiwayatQuery);
    $stmt->bind_param("ss", $status, $nomor_transaksi);
    $stmt->execute();

    // Cek apakah pembaruan berhasil
    if ($stmt->affected_rows > 0) {
        echo "Status berhasil diperbarui.";
    } else {
        echo "Gagal memperbarui status.";
    }

    $stmt->close();
}

$conn->close();
?>