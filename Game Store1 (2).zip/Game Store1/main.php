<?php
// Koneksi ke database MySQL
$servername = "localhost";
$username = "root";
$password = ""; // Biasanya kosong di XAMPP
$dbname = "game_store"; // Nama database

// Membuat koneksi
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Mengecek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
