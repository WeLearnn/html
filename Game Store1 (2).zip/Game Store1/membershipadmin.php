<?php

session_start();
// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}
$servername = "localhost";
$username = "root"; // Ganti jika username MySQL Anda berbeda
$password = ""; // Ganti jika password MySQL Anda berbeda
$dbname = "untuk_admin"; // Ganti nama database

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil game dari database
$result = $conn->query("SELECT * FROM tambah_game");

// Tangani penerapan diskon
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['apply_discount'])) {
    $discount_percentage = $_POST['discount_percentage'];
    $game_id = $_POST['game_id'];

    // Ambil harga asli
    $game_query = $conn->query("SELECT harga FROM tambah_game WHERE id='$game_id'");
    $game = $game_query->fetch_assoc();
    $original_price = $game['harga'];

    // Hitung harga baru
    $discount_amount = ($discount_percentage / 100) * $original_price;
    $new_price = $original_price - $discount_amount;

    // Perbarui harga di database (opsional)
    $conn->query("UPDATE tambah_game SET harga='$new_price' WHERE id='$game_id'");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Discounts</title>
  <style>
      /* =========== Google Fonts ============ */
      @import url("https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap");

/* =============== Globals ============== */
* {
    font-family: "Ubuntu", sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --blue: #1b182b;
    --white: #fff;
    --gray: #363434;
    --black1: #222;
    --black2: #999;
}

body {
    min-height: 100vh;
    overflow-x: hidden;
}

.container {
    position: relative;
    width: 100%;
}

/* =============== Navigation ================ */
.navigation {
    position: fixed;
    width: 300px;
    height: 100%;
    background: var(--blue);
    border-left: 10px solid var(--blue);
    transition: 0.5s;
    overflow: hidden;
}

.navigation.active {
    width: 80px;
}

.navigation ul {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
}

.navigation ul li {
    position: relative;
    width: 100%;
    list-style: none;
    border-top-left-radius: 30px;
    border-bottom-left-radius: 30px;
}

.navigation ul li:hover,
.navigation ul li.hovered {
    background-color: var(--white);
}

.navigation ul li:nth-child(1) {
    margin-bottom: 40px;
    pointer-events: none;
}

.navigation ul li a {
    position: relative;
    display: block;
    width: 100%;
    display: flex;
    text-decoration: none;
    color: var(--white);
}

.navigation ul li:hover a,
.navigation ul li.hovered a {
    color: var(--blue);
}

.navigation ul li a .icon {
    position: relative;
    display: block;
    min-width: 60px;
    height: 60px;
    line-height: 75px;
    text-align: center;
}

.navigation ul li a .icon ion-icon {
    font-size: 1.75rem;
}

.navigation ul li a .title {
    position: relative;
    display: block;
    padding: 0 10px;
    height: 60px;
    line-height: 60px;
    text-align: start;
    white-space: nowrap;
}

/* --------- curve outside ---------- */
.navigation ul li:hover a::before,
        .navigation ul li.hovered a::before {
            content: "";
            position: absolute;
            right: 0;
            top: -50px;
            width: 50px;
            height: 50px;
            background-color: transparent;
            border-radius: 50%;
            box-shadow: 35px 35px 0 10px var(--white);
            pointer-events: none;
        }

        .navigation ul li:hover a::after,
        .navigation ul li.hovered a::after {
            content: "";
            position: absolute;
            right: 0;
            bottom: -50px;
            width: 50px;
            height: 50px;
            background-color: transparent;
            border-radius: 50%;
            box-shadow: 35px -35px 0 10px var(--white);
            pointer-events: none;
        }

/* ===================== Main ===================== */
.main {
    position: absolute;
    width: calc(100% - 300px); /* Default width when navigation is visible */
    left: 300px; /* Default left position */
    min-height: 100vh;
    background: var(--white);
    transition: 0.5s;
}

.main.active {
    width: calc(100% - 80px); /* Width when navigation is collapsed */
    left: 80px; /* Left position when navigation is collapsed */
}

.membership-discount {
    padding: 20px; /* Add padding to the membership discount section */
}

.membership-discount h2 {
    font-weight: 600;
    color: var(--blue);
    margin-bottom: 20px;
}



.topbar {
    width: 100%;
    height: 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 10px;
}

.toggle {
    position: relative;
    width: 60px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 2.5rem;
    cursor: pointer;
}

.search {
    position: relative;
    width: 400px;
    margin: 0 10px;
}

.search label {
    position: relative;
    width: 100%;
}

.search label input {
    width: 100%;
    height: 40px;
    border-radius: 40px;
    padding: 5px 20px;
    padding-left: 35px;
    font-size: 18px;
    outline: none;
    border: 1px solid var(--black2);
}

.search label ion-icon {
    position: absolute;
    top: 0;
    left: 10px;
    font-size: 1.2rem;
}

.user {
    position: relative;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
    cursor: pointer;
}

.user img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* ======================= Game Management ====================== */
.gameManagement {
    padding: 20px;
}

.gameManagement h2 {
    font-weight: 600;
    color: var(--blue);
    margin-bottom: 20px;
}

.gameForm label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.gameForm input {
    width: calc(100% - 20px);
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid var(--black2);
    border-radius: 5px;
}

.gameForm button {
    padding: 10px 20px;
    background: var(--blue);
    color: var(--white);
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.gameTable {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.gameTable th,
.gameTable td {
    padding: 10px;
    border: 1px solid var(--black2);
    text-align: left;
}

.gameTable th {
    background: var(--blue);
    color: var(--white);
}

.gameTable tr:hover {
    background: var(--white);
}

.gameTable .editBtn,
```html
.gameTable .deleteBtn {
    padding: 5px 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.gameTable .editBtn {
    background: #ffc107;
    color: var(--white);
}

.gameTable .deleteBtn {
    background: #dc3545;
    color: var(--white);
}

/* ================== Responsive Design ========================== */
@media (max-width: 991px) {
    .navigation {
        left: -300px;
    }

    .navigation.active {
        width: 300px;
        left: 0;
    }

    .main {
        width: 100%;
        left: 0;
    }

    .main.active {
        left: 300px;
    }
}

@media (max-width: 768px) {
    .details {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .user {
        min-width: 40px;
    }

    .navigation {
        width: 100%;
        left: -100%;
        z-index: 1000;
    }

    .navigation.active {
        width: 100%;
        left: 0;
    }

    .toggle {
        z-index: 10001;
    }
}
  </style>
</head>

<body>
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="">
                        <span class="icon">
                            <ion-icon name="logo-apple-ar"></ion-icon>
                        </span>
                        <span class="title">Game Store Admin</span>
                    </a>
                </li>
                <li>
                    <a href="admin.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="crudgame.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">CRUD</span>
                    </a>
                </li>
                <li>
                    <a href="membershipadmin.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Membership Feature</span>
                    </a>
                </li>
                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <div class="user">
                    <!-- User profile image can be added here -->
                </div>
            </div>

            <div class="membership-discount">
                <h2>Membership Discounts</h2>

                <table class="gameTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Game Name</th>
                            <th>Genre</th>
                            <th>Rating</th>
                            <th>Harga</th>
                            <th>Apply Discount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama']); ?></td>
                                <td><?php echo htmlspecialchars($row['genre']); ?></td>
                                <td><?php echo htmlspecialchars($row['rating']); ?></td>
                                <td><?php echo htmlspecialchars($row['harga']); ?></td>
                                <td>
                                    <form method="POST">
                                        <input type="hidden" name="game_id" value="<?php echo $row['id']; ?>">
                                        <input type="number" name="discount_percentage" placeholder="Discount %" required>
                                        <button type="submit" name="apply_discount" class="applyBtn">Apply</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Menu Toggle
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function () {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };
    </script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>