<?php
$host = "localhost"; // Ganti dengan host database Anda
$user = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$database = "untuk_user"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn_user = new mysqli($host, $user, $password, $database);

// Memeriksa koneksi
if ($conn_user->connect_error) {
    die("Connection failed: " . $conn_user->connect_error);
}
?>