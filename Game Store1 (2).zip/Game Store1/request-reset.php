<?php
// Koneksi ke database
$servername = "localhost"; // Ganti dengan server database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "untuk_user"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Memeriksa apakah data dikirim melalui POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Memeriksa apakah email ada di database
    $stmt = $conn->prepare("SELECT email FROM informasi_user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Email ditemukan, arahkan pengguna ke halaman untuk mengganti password
        header("Location: gantipass.php?email=" . urlencode($email));
        exit();
    } else {
        echo "Email not found.";
    }

    $stmt->close();
}

$conn->close();
?>