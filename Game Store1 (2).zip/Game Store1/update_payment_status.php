<?php
$servername = "localhost"; // Ganti dengan nama server Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "untuk_admin"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data dari request
$data = json_decode(file_get_contents("php://input"), true);
$transactionId = $data['transactionId'];
$status = $data['status'];

// Update status pembayaran
$sql = "UPDATE transaksi_user SET status = ? WHERE nomor_transaksi = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $status, $transactionId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal memperbarui status']);
}

$stmt->close();
$conn->close();
?>